# Categorización de imágenes usando el dataset Fashion Mnist.

Puedes leer la descripción de la práctica aquí.