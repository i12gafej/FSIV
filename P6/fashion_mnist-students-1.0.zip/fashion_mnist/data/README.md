Puedes descargar el dataset desde [aquí](http://rabinf24.uco.es/fsiv/fashion-mnist.zip)

