/*!
  TRAIN A SIMPLE KNN CLASSIFIER.

  Se supone que se utilizará OpenCV.

  Para compilar, puedes ejecutar:
    g++ -Wall -o esqueleto esqueleto.cc `pkg-config opencv --cflags --libs`

*/

#include <iostream>
#include <string>
#include <exception>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

#include "dataset.hpp"

const char * keys =
    "{help h usage ? |      | print this message   }"
    "{@data          |./mnist/| folder with the dataset.}"
    ;


int main (int argc, char* const* argv)
{
  int retCode=EXIT_SUCCESS;

  try {
      cv::CommandLineParser parser(argc, argv, keys);
      parser.about("Load the fashion mnist dataset (binary format). "
                   "And train a simple KNN classifier.");
      if (parser.has("help"))
      {
          parser.printMessage();
          return 0;
      }
      std::string folder = parser.get<std::string>("@data");
      if (!parser.check())
      {
          parser.printErrors();
          return 0;
      }
      
      std::cout << "Loading data from folder: " << folder << std::endl;
      
      cv::Mat X, y;
      //  TODO: call function fsiv_load_dataset()
      // ...


      const int dataset_size = X.rows;
      std::cout << "Loaded " << dataset_size << " images." << std::endl;

      // #TODO: images are 28x28 pix, but we need to convert them to 1D feature vectors
      // A possible descriptor is computing the mean of each row (or column) of the image
      // ...
      cv::Mat X_1d;
      

      // #TODO: create the knn classifier with KNearest class
      // ...

      // #TODO: train the classifier with the train method
      // ...

      // #TODO: evaluate the classifier with the method 'findNearest'
      // ...

      // #TODO: compute the accuracy
      // ...
      float accuracy = 0.0f;

      std::cout << "Accuracy: " << accuracy << std::endl;



  }
  catch (std::exception& e)
  {
    std::cerr << "Capturada excepcion: " << e.what() << std::endl;
    retCode = EXIT_FAILURE;
  }
  catch (...)
  {
    std::cerr << "Capturada excepcion desconocida!" << std::endl;
    retCode = EXIT_FAILURE;
  }
  return retCode;
}
